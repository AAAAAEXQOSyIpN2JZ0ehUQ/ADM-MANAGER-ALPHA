﻿# ADM-MANAGER-ULTIMATE

## :heavy_exclamation_mark: Requirements
* Un sistema operativo basado en Linux (Ubuntu o Debian)
* Ubuntu 14.04 Server x86_64 / Ubuntu 16.04 Server x86_64
* Debian 8 Server x86_64 / Debian 9 Server x86_64
* Recomendamos Ubuntu 16.04 Server x86_64
* Se recomienda usar una distro nueva o formateada
* Idioma por defecto es el portugués

## :scroll: Changelog
**VERSION: 24377**

## :octocat: Credits
1. illuminati Dev Team - Contributor 
```
☆ https://t.me/AAAAAEXQOSyIpN2JZ0ehUQ [  ⃘⃤꙰✰ ] ☆
```
