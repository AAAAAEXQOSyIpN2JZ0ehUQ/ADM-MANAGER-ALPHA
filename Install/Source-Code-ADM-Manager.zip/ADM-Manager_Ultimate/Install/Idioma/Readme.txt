# Idiomas disponibles

1 - en English
2 - fr Franch
3 - de German
4 - it Italian
5 - pt Portuguese
6 - es Spanish
