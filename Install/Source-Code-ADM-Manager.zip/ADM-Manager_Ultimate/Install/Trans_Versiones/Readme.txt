Version =  "0.9.6.4" ReleaseDate =  "2017-06-01" 
Version =  "0.9.6.7" ReleaseDate =  "2018-03-17" 
Version =  "0.9.6.12" ReleaseDate =  "2020-05-11"
